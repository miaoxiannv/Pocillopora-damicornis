from mapping import Mapping
import os
import json
import csv
from datetime import datetime

class ResultWriter:
    def __init__(self, output_dir):
        """初始化结果写入器
        
        Args:
            output_dir (str): 输出目录路径
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
    def write_summary(self, mapping_results, enhanced_predictions):
        """写入汇总报告
        
        Args:
            mapping_results (dict): 原始映射结果
            enhanced_predictions (list): 增强后的预测结果，按置信度排序
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self._write_prediction_analysis(enhanced_predictions, timestamp)
        self._write_tsv_results(mapping_results, enhanced_predictions, timestamp)
        
    def _write_prediction_analysis(self, enhanced_predictions, timestamp):
        """写入增强后的预测分析结果
        
        Args:
            enhanced_predictions (list): 增强后的预测结果
            timestamp (str): 时间戳
        """
        output_file = os.path.join(self.output_dir, f'enhanced_predictions_{timestamp}.json')
        
        # 收集唯一的细胞类型
        cell_types = list(set(pred['predicted_type'] for pred in enhanced_predictions))
        
        analysis_results = {
            'timestamp': timestamp,
            'summary': {
                'total_predictions': len(enhanced_predictions),
                'unique_cell_types': len(cell_types),
                'cell_types': cell_types,
                'average_confidence': sum(p['enhanced_confidence'] for p in enhanced_predictions) / len(enhanced_predictions) if enhanced_predictions else 0,
                'predictions': enhanced_predictions
            }
        }
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(analysis_results, f, indent=2, ensure_ascii=False)
            
    def _write_tsv_results(self, mapping_results, enhanced_predictions, timestamp):
        """写入TSV格式结果
        
        Args:
            mapping_results (dict): 原始映射结果
            enhanced_predictions (list): 增强后的预测结果
            timestamp (str): 时间戳
        """
        output_file = os.path.join(self.output_dir, f'mapping_results_{timestamp}.tsv')
        
        # 准备表头和数据
        headers = ['sp2_cell_type', 'sp1_cell_type', 'overlap_count', 
                  'original_confidence', 'enhanced_confidence', 'overlap_genes']
        
        rows = []
        for pred in enhanced_predictions:
            sp2_type = pred['predicted_type']
            if sp2_type in mapping_results:
                for mapping in mapping_results[sp2_type]:
                    row = {
                        'sp2_cell_type': sp2_type,
                        'sp1_cell_type': mapping['sp1_cell_type'],
                        'overlap_count': mapping['overlap_count'],
                        'original_confidence': mapping['confidence'],
                        'enhanced_confidence': pred['enhanced_confidence'],
                        'overlap_genes': ','.join(sorted(mapping['overlap_genes']))
                    }
                    rows.append(row)
        
        # 写入TSV文件
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=headers, delimiter='\t')
            writer.writeheader()
            writer.writerows(rows)