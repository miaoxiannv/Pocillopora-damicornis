import numpy as np
from sklearn.ensemble import RandomForestClassifier

class PredictionEnhancer:
    def __init__(self):
        self.rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
        
    def enhance_predictions(self, cell_type_data):
        """使用机器学习增强预测结果"""
        try:
            if len(cell_type_data) < 2:
                return sorted(cell_type_data, key=lambda x: x['confidence'], reverse=True)

            X = np.array([d['features'] for d in cell_type_data], dtype=np.float64)
            y = np.array([d['predicted_type'] for d in cell_type_data])

            self.rf_model.fit(X, y)
            pred_probs = self.rf_model.predict_proba(X)

            for i, data in enumerate(cell_type_data):
                model_confidence = float(max(pred_probs[i]))
                data['enhanced_confidence'] = (data['confidence'] + model_confidence) / 2

            return sorted(cell_type_data, key=lambda x: x['enhanced_confidence'], reverse=True)
        except Exception as e:
            print(f"预测增强过程中出现错误: {str(e)}")
            return sorted(cell_type_data, key=lambda x: x['confidence'], reverse=True)