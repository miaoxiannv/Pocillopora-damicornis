from collections import defaultdict

import numpy as np
from sklearn.ensemble import RandomForestClassifier

from mapping import Mapping
from read_marker import ReadMarker
from read_ortho_group import ReadOrthoGroup


def process_single_pair(ortho_file, marker1_file, marker2_file):
    """处理单个物种对的数据"""
    ortho_group = ReadOrthoGroup(ortho_file, sp1_col=2, sp2_col=1)
    marker1 = ReadMarker(marker1_file)
    marker2 = ReadMarker(marker2_file)

    mapping = Mapping(ortho_group, marker1, marker2)
    mapping.test_overlap()
    mapping.mapping(min_overlap=3, min_confidence=0.01)

    return mapping


def process_all_pairs():
    """处理所有物种对"""
    # 定义数据路径
    data_pairs = {
        'FL-SP': {
            'ortho': r'CollateCode\Cell_type_mapping\data\FL-SP-cell\FL-SP-cell_Orthogroups.tsv',
            'marker1': r'CollateCode\Cell_type_mapping\data\FL-SP-cell\SP-cell_marker.tsv',
            'marker2': r'CollateCode\Cell_type_mapping\data\FL-SP-cell\all_markers.tsv'
        },
        'PD-SP': {
            'ortho': r'CollateCode\Cell_type_mapping\data\PD-SP-cell\PD-SP-cell_Orthogroups.tsv',
            'marker1': r'CollateCode\Cell_type_mapping\data\PD-SP-cell\SP-cell_marker.tsv',
            'marker2': r'CollateCode\Cell_type_mapping\data\PD-SP-cell\all_markers.tsv'
        },
        'PV-SP': {
            'ortho': r'CollateCode\Cell_type_mapping\data\PV-SP-cell\PV-SP-cell_Orthogroups.tsv',
            'marker1': r'CollateCode\Cell_type_mapping\data\PV-SP-cell\SP-cell_marker.tsv',
            'marker2': r'CollateCode\Cell_type_mapping\data\PV-SP-cell\all_markers.tsv'
        },
        'SP-SP': {
            'ortho': r'CollateCode\Cell_type_mapping\data\SP-SP-cell\SP-SP-cell_Orthogroups.tsv',
            'marker1': r'CollateCode\Cell_type_mapping\data\SP-SP-cell\SP-cell_marker.tsv',
            'marker2': r'CollateCode\Cell_type_mapping\data\SP-SP-cell\all_markers.tsv'
        }
    }

    # 处理每个物种对
    results = {}
    for name, files in data_pairs.items():
        print(f"\n处理 {name} 物种对...")
        results[name] = process_single_pair(
            name,
            files['ortho'],
            files['marker1'],
            files['marker2']
        )

    # 生成汇总报告
    generate_summary(results)
    



def generate_summary(results):
    """生成汇总报告，使用机器学习算法增强预测能力"""
    with open('out/summary_results.txt', 'w', encoding='utf-8') as f:
        # 写入总体统计信息
        f.write("各物种对基因统计汇总\n")
        f.write("=" * 50 + "\n\n")

        for name, mapping in results.items():
            stats = mapping.get_statistics()
            f.write(f"{name} 物种对统计:\n")
            f.write("-" * 30 + "\n")
            f.write(f"SP1 marker基因数量: {stats['sp1_marker']}\n")
            f.write(f"SP2 marker基因数量: {stats['sp2_marker']}\n")
            f.write(f"SP1 直系同源基因数量: {stats['sp1_ortho']}\n")
            f.write(f"SP2 直系同源基因数量: {stats['sp2_ortho']}\n")
            f.write(f"SP1 marker基因与直系同源基因重叠率: {stats['sp1_overlap_rate']:.2%}\n")
            f.write(f"SP2 marker基因与直系同源基因重叠率: {stats['sp2_overlap_rate']:.2%}\n\n")

        # 添加机器学习预测分析
        f.write("\n跨物种细胞类型预测分析（机器学习增强）\n")
        f.write("=" * 50 + "\n\n")

        # 收集所有预测数据
        prediction_data = defaultdict(list)
        features_data = []
        labels = []

        for name, mapping in results.items():
            mapping_results = mapping.get_mapping_results()
            for sp2_type, mappings in mapping_results.items():
                if mappings:
                    for map_result in mappings:
                        # 构建特征向量
                        features = [
                            float(map_result['confidence']),
                            float(len(map_result.get('overlap_genes', set()))),  # 重叠基因数量而不是集合
                            float(map_result.get('marker_ratio', 0)),  # marker基因比例
                            float(len(map_result.get('shared_pathways', []))),  # 共享通路数
                        ]

                        features_data.append(features)
                        labels.append(map_result['sp1_cell_type'])

                        prediction_data[sp2_type].append({
                            'features': features,
                            'predicted_type': map_result['sp1_cell_type'],
                            'species_pair': name,
                            'confidence': map_result['confidence']
                        })

        # 使用随机森林进行预测增强
        def enhance_predictions(cell_type_data):
            try:
                if len(cell_type_data) < 2:  # 数据太少，使用简单规则
                    return sorted(cell_type_data, key=lambda x: x['confidence'], reverse=True)

                X = np.array([d['features'] for d in cell_type_data], dtype=np.float64)
                y = np.array([d['predicted_type'] for d in cell_type_data])

                # 训练随机森林模型
                rf = RandomForestClassifier(n_estimators=100, random_state=42)
                rf.fit(X, y)

                # 获取预测概率
                pred_probs = rf.predict_proba(X)

                # 结合原始置信度和模型预测
                for i, data in enumerate(cell_type_data):
                    model_confidence = float(max(pred_probs[i]))
                    data['enhanced_confidence'] = (data['confidence'] + model_confidence) / 2

                return sorted(cell_type_data, key=lambda x: x['enhanced_confidence'], reverse=True)
            except Exception as e:
                print(f"预测增强过程中出现错误: {str(e)}")
                # 发生错误时返回原始排序结果
                return sorted(cell_type_data, key=lambda x: x['confidence'], reverse=True)

        # 对每个细胞类型进行增强预测
        for cell_type, predictions in prediction_data.items():
            f.write(f"\n细胞类型 {cell_type} 的增强预测分析:\n")
            f.write("-" * 30 + "\n")

            enhanced_predictions = enhance_predictions(predictions)

            # 使用加权投票系统
            vote_results = defaultdict(float)
            for pred in enhanced_predictions:
                vote_results[pred['predicted_type']] += pred['enhanced_confidence']

            # 计算预测的可靠性分数
            reliability_scores = {}
            for pred_type, vote_score in vote_results.items():
                # 计算支持的物种对数量
                supporting_species = len(set(p['species_pair'] for p in enhanced_predictions
                                             if p['predicted_type'] == pred_type))

                # 可靠性分数计算
                reliability = vote_score * (supporting_species / len(results))  # 归一化的物种支持度
                reliability_scores[pred_type] = reliability

            # 输出预测结果
            for pred_type, reliability in sorted(reliability_scores.items(),
                                                 key=lambda x: x[1], reverse=True):
                supporting_preds = [p for p in enhanced_predictions
                                    if p['predicted_type'] == pred_type]

                f.write(f"\n预测类型: {pred_type}\n")
                f.write(f"可靠性分数: {reliability:.3f}\n")
                f.write(f"支持物种对数量: {len(set(p['species_pair'] for p in supporting_preds))}\n")
                f.write(f"平均增强置信度: {np.mean([p['enhanced_confidence'] for p in supporting_preds]):.2%}\n")
                f.write(f"支持的物种对: {', '.join(set(p['species_pair'] for p in supporting_preds))}\n")

                # 添加预测理由
                f.write("预测依据:\n")
                for evidence in supporting_preds[:3]:  # 显示前三个最强的证据
                    f.write(f"- 来自{evidence['species_pair']}的映射 "
                            f"(置信度: {evidence['enhanced_confidence']:.2%})\n")
                f.write("\n")

        # 添加预测质量评估
        f.write("\n预测质量评估\n")
        f.write("=" * 50 + "\n")
        f.write("高可靠性预测 (可靠性分数 > 0.7):\n")
        high_reliability_predictions = {cell_type: preds for cell_type, preds
                                        in prediction_data.items()
                                        if max(vote_results.values()) > 0.7}
        for cell_type, preds in high_reliability_predictions.items():
            f.write(f"- {cell_type}: {preds[0]['predicted_type']}\n")

        # 保存预测结果到tsv文件
        with open(r'CollateCode\Cell_type_mapping\out\res.tsv', 'w', encoding='utf-8') as tsv_file:
            # 写入表头
            tsv_file.write(
                "target_cell_type\tpredicted_cell_type\treliability_score\tsupporting_species\taverage_confidence\tsupporting_pairs\n")

            # 写入每个预测结果
            for cell_type, predictions in prediction_data.items():
                enhanced_predictions = enhance_predictions(predictions)

                # 计算可靠性分数
                vote_results = defaultdict(float)
                for pred in enhanced_predictions:
                    vote_results[pred['predicted_type']] += pred['enhanced_confidence']

                # 获取最佳预测结果
                best_prediction = sorted(vote_results.items(), key=lambda x: x[1], reverse=True)[0]
                pred_type = best_prediction[0]

                # 获取支持该预测的数据
                supporting_preds = [p for p in enhanced_predictions if p['predicted_type'] == pred_type]
                supporting_species = len(set(p['species_pair'] for p in supporting_preds))
                avg_confidence = np.mean([p['enhanced_confidence'] for p in supporting_preds])
                supporting_pairs = ','.join(set(p['species_pair'] for p in supporting_preds))

                # 写入结果行
                tsv_file.write(
                    f"{cell_type}\t{pred_type}\t{best_prediction[1]:.3f}\t{supporting_species}\t{avg_confidence:.3f}\t{supporting_pairs}\n")


if __name__ == "__main__":
    process_all_pairs()
